Name: Joshua Capron

Code: CSE 212-02 Final Project (Data Structure Tutorial)

Github: JoshuaCapron64

Student email: cap17008@byui.edu

Hello, and welcome to my Data Structure tutorial! I will be showcasing the usage of three integral Data Structures using the Python programming language, namely Queue, Set, and Tree. Links to each tutorial can be found below.

Queue:

On Github:
[Queue Tutorial](https://github.com/JoshuaCapron64/cse212-final-project/blob/main/queue.md)

On VSCode:
[Queue Tutorial](queue.md)

Set:

On Github:
[Set Tutorial](https://github.com/JoshuaCapron64/cse212-final-project/blob/main/set.md)

on VSCode:
[Set Tutorial](set.md)

Tree:

On Github:
[Tree Tutorial](ttps://github.com/JoshuaCapron64/cse212-final-project/blob/main/tree.md)

On VSCode:
[Tree Tutorial](tree.md)