I. Welcome
    Name: Joshua Capron
    Code: CSE 212 Final Project (Data Structure Tutorial)
    Github: JoshuaCapron64
    Student email: cap17008@byui.edu

II. Data Structures to be Covered:
    -queue (might possibly change to stack)
    -set (might possibly change to linked list)
    -tree

III. Queue:
    -Introduction
    -uses/why use Queues
    -Big O Notation
    -enqueue()
    -dequeue()
    -example
    -problem

IV. Set:
    -Introduction
    -uses/why use Sets
    -Big O Notation
    -add()
    -update()
    -pop()
    -clear()
    -example
    -problem

V. Tree:
    -Introduction
    -uses/why use Trees
    -Big O Notation
    -nodes
    -traversals
    -example
    -problem
