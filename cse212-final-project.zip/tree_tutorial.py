#Do not change any of the following code:
class Node:
    def __init__(self, item):
        self.item = item
        self.right = None
        self.left = None

#TODO add whatever code you want here