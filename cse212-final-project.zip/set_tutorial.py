class set_problem:
    #Do not change any of the following code:
    your_set = {7, 3, 11, 15, 8, 2}
    print(your_set)

    #TODO add whatever code you want here:


    #Do not change any of the following code:
    print(your_set)
